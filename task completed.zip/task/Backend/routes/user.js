const express = require("express");

const router = express.Router();

router.post("/",require("./../controllers/user").Createuser);

// router.post('/forgot-password', require("./../controllers/user").sendPasswordResetEmail);



router.get("/",require("./../controllers/user").getAlluser);
router.get("/:userId",require("./../controllers/user").getUser);
router.put("/:userId",require("./../controllers/user").updateUser);
router.delete("/:userId",require("./../controllers/user").deleteUser);

module.exports = router;