
// const nodemailer = require("nodemailer");

const userModel = require("./../models/user");

exports.Createuser = async(req,res) =>
{
    console.log(req.body);
    try
    {
        const data = await new userModel(req.body).save();
        res.json(data);
    }
    catch(err)
    {
        res.json(err);
    }
}

exports.getAlluser= async(req,res) =>
{
    try
    {
        const getdata = await userModel.find();
        res.json(getdata);
    }
    catch(err)
    {
        res.json(err);
    }
}

exports.getUser = async(req,res) =>
{
    try
    {
        const getId = await userModel.find({_id:req.params.userId});
        res.json(getId);
    }
    catch(err)
    {
        res.json(err);
    }
}

exports.updateUser = (req,res) =>
{
    userModel.findByIdAndUpdate({_id:req.params.userId},req.body,{new:true},(err,data)=>
    {
        if(err)
        {
            res.json(err);
        }
        else
        {
            res.json(data);
        }
    });
}

exports.deleteUser = (req,res) =>
{
    userModel.findByIdAndDelete({_id:req.params.userId},(err,data)=>
    {
        if(err)
        {
            res.json(err);
        }
        else
        {
            res.json(data);
        }
    })
}
// exports.sendPasswordResetEmail = async(req,res)=>
// {
//     const { email } = req.body;
//     try {
//         const user = await userModel.findOne({ email });
//         if (!user) {
//             return res.status(404).json({ message: 'User not found' });
//         }

//         // Generate and save password reset token
//         const resetToken = user.generatePasswordResetToken();
//         await user.save();

//         // Send email with password reset link
//         await sendResetPasswordEmail(user.email, resetToken);

//         return res.status(200).json({ message: 'Password reset email sent successfully' });
//     } catch (error) {
//         console.error(error);
//         return res.status(500).json({ message: 'Internal server error' });
//     }
//     }
