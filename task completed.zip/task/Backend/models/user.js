const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
    fullName:String,
    emailId:String,
    moNumber:Number,
    password:String,
    username:{type:String,required:true,unique:true},
    loginemailId:{type:String,required:true,unique:true},
    loginpassword:{type:String,required:true,unique:true},
    email:String,
    designation:String,

})

module.exports = mongoose.model("user",userSchema);