import React, { useState } from "react";
import "./Login.css";
import Axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const Login = () => {
  const [username, setUsername] = useState("");
  const [loginemailId, setEmailId] = useState("");
  const [loginpassword, setPassword] = useState("");
  const navigate = useNavigate();

  const handlesubmit = async (e) => {
    e.preventDefault();
    
    // Create form data
    const data = {
      username,
      loginemailId,
      loginpassword
    };

    // Validate form data
    const validationErrors = validateForm(data);
    if (Object.keys(validationErrors).length > 0) {
      toast.error('Please fill in all required fields.');
      return;
    }

    try {
      // Make POST request
      await Axios.post('http://localhost:7005/user', data);
      
      // Show success notification
      toast.success('User created successfully!');
      
      // Redirect to another page
      navigate('/');
    } catch (err) {
      console.log(err);
      toast.error('An error occurred, please try again.');
    }
  };

  const validateForm = (data) => {
    let errors = {};
    if (!data.username) {
      errors.username = 'Username is required';
    }
    if (!data.loginemailId) {
      errors.loginemailId = 'Email is required';
    }
    if (!data.loginpassword) {
      errors.loginpassword = 'Password is required';
    }
    return errors;
  };

  return (
    <>
      <div className="Sign-up-container">
        <form className="sign-up-form" onSubmit={handlesubmit}>
          <h2>Sign Up</h2>
          
          <label htmlFor="username">Username:</label>
          <input
            type="text"
            className="form-control"
            id="exampleInputText1"
            aria-describedby="textHelp"
            onChange={e => setUsername(e.target.value)}
            value={username}
          />
          
          <br />
          
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            className="form-control"
            id="exampleInputEmail1"
            aria-describedby="emailHelp"
            onChange={e => setEmailId(e.target.value)}
            value={loginemailId}
          />
          
          <br />
          
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            className="form-control"
            id="exampleInputPassword1"
            onChange={e => setPassword(e.target.value)}
            value={loginpassword}
          />
          
          <br />
          
          <button type="submit">Sign Up</button>
          
          <p>Have an Account <Link to="/register">Login In</Link></p>
        </form>
      </div>
      
      <ToastContainer />
    </>
  );
};

export default Login;
