import React, { useEffect, useState } from 'react';
import axios from 'axios';
import {NavLink,useParams } from 'react-router-dom';


const UserTable = () => {
  const [users, setUsers] = useState([]);
  const {userID} = useParams();
  console.log(userID);

  const [fullName,setFullName] = useState();
  const [emailId,setEmailId] = useState();
  const [moNumber,setMoNumber] = useState();
  const [password,setPassword] = useState();




  const data=
  {
    fullName,
    emailId,
    moNumber,
    password
  }
  console.log(data);
  useEffect(() => {
    axios.get(`http://localhost:7005/user/${userID}`,data)
    
    
      .then(res => {
        setUsers(res.data);
      })
      .catch(err => {
        console.log(err);
      })
  }, []);

  return (
    <>
    <div>
    <form><br/>
     <h2><b>View The Data</b></h2><br/>
        {users.map(user => (
          <tr key={user._id}>
             <div class="mb-3">
    <label for="exampleInputText1" className="form-label">Full Name</label>
    <input type="text" className="form-control" id="exampleInputText1" onChange={e=>setFullName(e.target.value)} value={user.fullName} aria-describedby="textHelp"/>
  </div>
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Email address</label>
    <input type="email" className="form-control" id="exampleInputEmail1" onChange={e=>setEmailId(e.target.value)} value={user.emailId} aria-describedby="emailHelp"/>
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" className="form-label">Password</label>
    <input type="password" className="form-control" id="exampleInputPassword1"onChange={e=>setPassword(e.target.value)} value={user.password} />
  </div>
  <div class="mb-3">
    <label for="exampleInputNumber" class="form-label">Mobile Number</label>
    <input type="number" class="form-control" id="exampleInputNumber" onChange={e=>setMoNumber(e.target.value)} value={user.moNumber}  aria-describedby="numberHelp"/>
  </div>
            {/* <td>{user.fullName}</td>
            <td>{user.emailId}</td>
            <td>{user.moNumber}</td> */}
       
  <NavLink exact to="/"><button type="button" class="btn btn-secondary">Back</button></NavLink>      
          
          </tr>
        ))}
</form>
           </div> 
        </>
  );
}

export default UserTable;