import React from 'react';
import {  Routes, Route } from 'react-router-dom';

// import Adduser from "./Adduser"; 
import Login from "./Login";
import Edit from './Edit';
import Delete from './Delete';
import UserTable from './View';
import Register from './Register';
import Forget from './forget';


const Routing = () => {
    return (
        <div className='container'>
            <Routes>
              <Route exact path='/' element={<Login/>}/>
              {/* <Route exact path='/add' element={<Adduser/>}/> */}
              <Route exact path='/login' element={<Login/>}/>
              <Route exact path='/register' element={<Register/>}/>
              <Route exact path='/forgotpassword' element={<Forget/>}/>


        


              <Route exact path='/edit/:userID' element={<Edit/>}/>
            <Route exact path='/delete/:userID' element={<Delete/>}/>
            <Route exact path='/view/:userID' element={<UserTable />}/>
            </Routes>
        </div>
    );
};

export default Routing;