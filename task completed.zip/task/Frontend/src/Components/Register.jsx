import React, { useState } from "react";
import "./Login.css";
import Axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const Login = () => {
  const [loginemailId, setEmailId] = useState("");
  const [loginpassword, setPassword] = useState("");
  const navigate = useNavigate();

  const handlesubmit = async (e) => {
    e.preventDefault();
    try {
      await Axios.post('http://localhost:7005/user', {
        loginemailId,
        loginpassword,
      });
      
      // Show success notification
      toast.success('Hello');

      // Redirect to home page
      navigate('/');
    } catch (err) {
      console.log(err);
      // Show error notification
      toast.error('An error occurred. Please try again.');
    }
  };

  return (
    <>
      <div className="Sign-up-container">
        <form className="sign-up-form" onSubmit={handlesubmit}>
          <h2>Login Account</h2>

          <br />
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            autoComplete="off"
            placeholder="Email"
            onChange={(e) => setEmailId(e.target.value)}
            value={loginemailId}
          />
          <br />
          <br />
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            placeholder="*********"
            onChange={(e) => setPassword(e.target.value)}
            value={loginpassword}
          />

          <br />
          <br />
          <br />
          <button type="submit">Login</button>
          <Link to="/forgotpassword">Forget Password</Link>
          <p>Don't Have an Account <Link to="/login">Sign In</Link></p>
        </form>
      </div>
      
      {/* ToastContainer for notifications */}
      <ToastContainer />
    </>
  );
};

export default Login;
