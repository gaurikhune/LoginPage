import React from 'react';
import axios from 'axios';
import { NavLink, useParams ,useNavigate} from 'react-router-dom';

const Delete = () => {
const navigate = useNavigate();
    const {userID} = useParams();
    console.log(userID);
   const deleteHandler = async() =>
   {
    await axios.delete(`http://localhost:7005/user/${userID}`)
    .then((res)=>
    {
      alert("User Deleted");
      navigate('/')
    })
    .catch(err=>alert(err));
   }
    

    return (
        <><br/>
        <h2><b>Delete The User's Data</b></h2> <br/> 
   <h3>Are You Sure</h3>
  <NavLink exact to="/delete"><button type="button" className="btn btn-danger"onClick={deleteHandler}>Yes</button></NavLink>&nbsp;&nbsp;
  <NavLink exact to="/"><button type="button" className="btn btn-secondary">Back</button></NavLink>

        </>
    );
};

export default Delete;