import React, { useState } from "react";
import "./Login.css";
import Axios from "axios";
// import {Link , useNavigate } from "react-router-dom";

const Forget=()=> {


  const [email, setEmail] = useState("");
  
// const navigate = useNavigate()
const handlesubmit = async (e) => {
  e.preventDefault();
  try {
      await Axios.post('http://localhost:7005/forgot-password', { email });
      alert('Password reset email sent successfully');
  } catch (error) {
      console.error(error);
      alert('Error sending password reset email');
  }
};
  return (
    <>
    <div className="Sign-up-container">
      <form className="sign-up-form" onSubmit={handlesubmit}>
        <h2> Forgot Password</h2>
       

        <br />
        <label htmlFor="email">Email:</label>
        <input
          type="email"
          autoComplete="off"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <br />
   
      
       

        
        <br />
        <button type="submit">Send</button>
      
      
      </form> 
    </div>
  </>
  )
}
export default Forget