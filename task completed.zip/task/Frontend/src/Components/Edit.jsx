import axios from 'axios';
import React from 'react';
import { useState } from 'react';
import { NavLink, useParams } from 'react-router-dom';

const Edit = () => {

  const {userID} = useParams();
  console.log(userID);

const [fullName,setFullName] = useState();
const [emailId,setEmailId] = useState();
const [moNumber,setMoNumber] = useState();
const [password,setPassword] = useState();

const submitHandler =async (e) =>
{
e.preventDefault();

const data=
{
  fullName,
  emailId,
  moNumber,
  password
}
console.log(data);
await axios.put(`http://localhost:7005/user/${userID}`,data)
.then((res)=>
{
  alert("User Updated");
})
.catch(err=>alert(err));

}


    return (
        <>
           <div>
           <form onSubmit={submitHandler}><br/>
            <h2><b>Update The Data</b></h2><br/>
           <div class="mb-3">
    <label for="exampleInputText1" className="form-label">Full Name</label>
    <input type="text" className="form-control" id="exampleInputText1" onChange={e=>setFullName(e.target.value)} value={fullName} aria-describedby="textHelp"/>
  </div>
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Email address</label>
    <input type="email" className="form-control" id="exampleInputEmail1" onChange={e=>setEmailId(e.target.value)} value={emailId} aria-describedby="emailHelp"/>
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" className="form-label">Password</label>
    <input type="password" className="form-control" id="exampleInputPassword1"onChange={e=>setPassword(e.target.value)} value={password} />
  </div>
  <div class="mb-3">
    <label for="exampleInputNumber" class="form-label">Mobile Number</label>
    <input type="number" class="form-control" id="exampleInputNumber" onChange={e=>setMoNumber(e.target.value)} value={moNumber}  aria-describedby="numberHelp"/>
  </div>

  <button type="submit" class="btn btn-primary">Submit</button>&nbsp;&nbsp;
  <NavLink exact to="/"><button type="button" class="btn btn-secondary">Back</button></NavLink>
</form>
           </div> 
        </>
    );
};

export default Edit;