import React from 'react';
import { BrowserRouter } from 'react-router-dom';
// import Home from './Components/Home';
import Routing from "./Components/Routing";


const App = () => {
  return (
    <div>     
       <BrowserRouter> 
            
          <Routing/>
       </BrowserRouter>
    </div>
  );
};

export default App;